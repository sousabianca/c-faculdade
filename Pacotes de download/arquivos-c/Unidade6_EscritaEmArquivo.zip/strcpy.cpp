#include <stdio.h>
#include <conio.h>
#include <string.h>

main(){
char str1[80],str3[50];
char str2[44]={"Corinthians levou o gol do R O G E R 1 O O"};
strcpy(str1,str2);
strcpy (str3,"\nTristeza para uns, alegria para outros.");
printf("%s %s",str3,str1);
printf("\n\n%s",str2);
getch();}
