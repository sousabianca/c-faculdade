#include <conio.h>
#include <stdio.h>
#include <string.h>

struct automovel{
int ano,renavam;
char nome[15],marca[10],cor[10],combustivel[10];
};
 main()
{
//struct automovel;
int i;

for(i=0;i<2;i++)
{printf("\nEntre com o nome do automovel: ");
scanf("%s",&automovel[i].nome);
printf("Entre com a marca: ");
scanf("%s",&automovel[i].marca);
printf("Entre com a cor: ");
scanf("%s",&automovel[i].cor);
printf("Entre com o combustivel: ");
scanf("%s",&automovel[i].combustivel);
printf("Entre com o ano: ");
scanf("%d",&automovel[i].ano);
printf("Entre com o Renavam: ");
scanf("%d",&automovel[i].renavam);
}
printf("\tnome \tmarca \tcor \tcombustivel \tano \tRenavam\n");
for(i=0;i<2;i++)
{printf(" \t%s \t%s \t%s \t%s \t\t%d \t  %d\n",automovel[i].nome,automovel[i].marca,automovel[i].cor,automovel[i].combustivel, automovel[i].ano,automovel[i].renavam);}
getch();}
