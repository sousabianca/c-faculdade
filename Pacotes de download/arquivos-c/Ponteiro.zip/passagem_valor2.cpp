#include <stdio.h>
#include <conio.h>
float sqr (float);
 main ()
{
	float num,sq;
	printf ("Entre com um numero: ");
	scanf ("%f",&num);
	sq=sqr(num);
	printf ("\n\nO numero original e: %f\n",num);
	printf ("O seu quadrado vale: %f\n",sq);
	getch();
}

float sqr (float X)
{
	X=X*X;
	return X;
}
