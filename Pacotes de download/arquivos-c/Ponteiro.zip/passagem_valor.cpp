#include <stdio.h>
#include <conio.h>
main()
{
int a,r,x;
int soma(int);
printf("Digite um valor: ");
scanf("%d",&a);
x = 2 * a + 3;
r = soma(a);
printf("%d, %d e %d",a,x,r);
getch();
}

int soma(int a)
{
int x=5;
x = 2 * x + a;
return(x);
}
