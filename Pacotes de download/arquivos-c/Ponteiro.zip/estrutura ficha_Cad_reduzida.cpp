#include <conio.h>
#include <stdio.h>
#include <string.h>

struct est_endereco
{
char rua[50];
int numero;
};
struct ficha{
int matricula;
char nome [45];
float salario;
struct est_endereco endereco;
};

int main(void)
{
 int i;
 struct ficha f1;

   printf("Entre com a matricula do funciona'rio: ");
   scanf("%d",&f1.matricula);
   printf("\nEntre com o nome: ");
   fflush(stdin); // para limpar o buffer do teclado
   gets(f1.nome);
   printf("\nEntre com o salario: ");
   scanf("%f",&f1.salario);
// Acessando a estrutra est_endere�o
   printf("\nEntre com a rua: ");
   scanf("%s",&f1.endereco.rua);
   printf("\nEntre com o nu'mero: ");
   scanf("%d",&f1.endereco.numero);
// imprimindo os registros
    printf(" \t%d \n",f1.matricula );
    printf(" \t%s \n",f1.nome);    
    printf(" \t%f \n",f1.salario );
    printf(" \t%s \n",f1.endereco.rua );
    printf(" \t%d \n",f1.endereco.numero );
getch();}
