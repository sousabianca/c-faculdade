# include<stdio.h>
# include<conio.h>
int main ()
{
float matrx [50][50];
int i,j;
for (i=0;i<50;i++)
{for (j=0;j<50;j++)
  matrx[i][j]=0.0;
    }
    for (i=0;i<50;i++)
    for (j=0;j<50;j++)
{printf("\n matriz[%d][%d] = %f ",i,j,matrx[i][j]);}
getch();
return(0);
}
