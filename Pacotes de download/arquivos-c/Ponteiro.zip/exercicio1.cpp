#include <stdio.h>
#include <conio.h>
int main ()
{
int x,*px;
//int w;
float y, *py;
x=10;
y=1.2;
//w=15;
px=&x;
py=&y;

printf ("\nO endere�o de x e: %p \n",px);
printf ("\nO endere�o de y e: %p \n",py);
printf ("\nO endere�o de x e: %p \n",&x);
printf ("\nO endere�o de y e: %p \n",&y);
*py=2.5;
printf ("\nValor de x e: %d\n",*px);
printf ("\nValor de y e: %.2f\n",*py);
printf ("\nValor de x e: %d\n",x);
printf ("\nValor de y e: %.2f\n",y);
//px=&w;
//printf ("\nO endere�o de w e: %p \n",px);

getch();
return(0);
}
