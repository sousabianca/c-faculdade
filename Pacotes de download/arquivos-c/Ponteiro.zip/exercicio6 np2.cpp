#include<stdio.h>
#include<conio.h>
int main(){
    int v[5]={ 2, 0, 4, 3, 1 };
    int i, j, a;
    for (i=0;i<=3;i++)  {
       for (j=0;j<=(3-i);j++) {
             if (v[j]>v[j+1])      {
                   a=v[j];
                   v[j]=v[j+1];
                   v[j+1]=a;
         }
         printf("\n %d %d %d %d %d %d %d", i, j, v[0], v[1], v[2], v[3], v[4]) ;
       }    }  }

