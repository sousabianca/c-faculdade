#include <stdio.h>
#include <conio.h>
int main ()
{
short int vetor1[10] = { 1, 2, 3, 4, 5 };
short int vetor2[10] = { 1, 2, 3, 4, 5 };
short int *W,*Z,x;
W=vetor1;
Z=vetor2;
x=*(W+2)+*(Z+3);
printf ("\n\n A soma do 3o elemento com o 4o. e': %d",x);

getch();
return(0);
}
