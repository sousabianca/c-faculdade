#include <stdio.h>
#include <conio.h>
int main ()
{
 int x = 10;
 float y =11;
 int *p;
p = &x;
printf("\n &x = %d ",&x);  // 
printf("\n p = %d ",p);

printf("\n x = %p ",*p);
printf("\n p = %d ",x);

getch();
return(0);
}
