//Ponteiros como par�metros de fun��o

/*Quando queremos alterar o valor dos argumentos passados para uma fun��o 
devemos definir os par�metros da fun��o como ponteiros. 
A isso denominamos chamada por refer�ncia. Exemplo:*/

/* ponteiros como par�mteros de fun��o */

#include <stdio.h>
#include <stream.h>

/* a fun��o que recebe como argumento o valor
 * da vari�vel n�o consegue alterar o valor
 * deste
 */
int valor(int a)
  {
    a = 26; /* alterando o valor do argumento passado */
  }

/* a fun��o que recebe como argumento um ponteiro
 * consegue alterar o valor apontado por este
 */
int ponteiro(int *a)
  {
    *a  = 35; /* alterando o valor do argumento passado */
  }


int main()
  {
    int nr = 26;
    int *ptr_nr;

    printf("O valor inicial de nr e' %d\n",nr);

    valor(nr); /* fun��o que recebe o valor. N�o consegue alterar este */
    printf("Valor de nr apo's a chamada da funcao valor = %d\n",nr);

    ptr_nr = &nr;
    ponteiro(ptr_nr); /* fun��o que recebe ponteiro. Consegue alterar valor
                       * apontado
                       */
    printf("Valor de nr apo's a chamada da funcao ponteiro = %d\n",nr);
system("pause");
    return(0);
  }
