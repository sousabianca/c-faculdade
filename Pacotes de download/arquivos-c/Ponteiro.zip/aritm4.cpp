# include<stdio.h>
# include<conio.h>

int main ()
{
char x, *p1, *p2;
short int y, *p3, *p4;
float z, *p5, *p6;

//vari�vel do tipo char 1 byte
p1=&x;
p2=p1;
printf("p2  =%p", p2);
p2++;
printf("\np2++=%p", p2);
//vari�vel do tipo int 2 bytes
p3=&y;
p4=p3;
printf("\n\np4  =%p", p4);
p4++;
printf("\np4++=%p", p4);
//vari�vel do tipo float 4 bytes
p5=&z;
p6=p5;
printf("\n\np6  =%p", p6);
p6++;
printf("\np6++=%p", p6);

getch();

return(0);
}
