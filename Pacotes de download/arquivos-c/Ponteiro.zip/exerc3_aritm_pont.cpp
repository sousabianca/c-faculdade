#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

main()
{
float Resp, a, b;
float *pta,*ptb;
pta=&a;
ptb=&b;
      printf("Entre com os valores de a e b\n");
      scanf("%f %f",&a,&b);
	  Resp = *pta + *ptb;
	  printf("\nO valor da soma e':%f",Resp);
	  getch();
   }
