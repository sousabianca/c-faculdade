#include <conio.h>
#include <stdio.h>
#include <string.h>
#define tam 1
struct automovel{
int ano,km;
float custo_manut;
char Nome_Prop[30],Marca[10], Fabr[10], Placa[7], Tipo_Manut[30];
}p[tam];
int main(void)
{
int i;
// ? struct automovel p[tam];?
for(i=0;i<tam;i++)
   {
   fflush(stdin);
   printf("\nEntre com o nome do proprieta'rio: ");
   gets(p[i].Nome_Prop);
   printf("\nEntre com a marca do automovel: ");
   scanf("%s",&p[i].Marca);
   printf("Entre com o fabricante: ");
   gets(p[i].Fabr);
   printf("Entre com o ano de fabrica��o: ");
   scanf("%d",&p[i].ano);
   printf("Entre com a Placa: ");
   scanf("%s",&p[i].Placa);
   printf("Entre com a quilometragem: ");
   scanf("%d",&p[i].km);
   printf("Entre com o tipo de manuten��o: ");
   gets(p[i].Tipo_Manut);
   printf("Entre com o custo: ");
   scanf("%f",&p[i].custo_manut);
   }

for(i=0;i<tam;i++)
   {
   printf(" \t%s \t%s \t%s \n",p[i].Nome_Prop,p[i].Marca,p[i].Fabr);
   printf(" \t%d \t%s \t%d \n",p[i].ano,p[i].Placa,p[i].km);
   printf(" \t%s \t%s \t%f \n",p[i].Tipo_Manut,p[i].custo_manut);
   }
getch();}

