#include <conio.h>
#include <stdio.h>
#include <string.h>

struct automovel{
int ano;
float valor;
char nome[15],cor[10];
}Carro[3];
 main()
{
int i;
for(i=0;i<2;i++)
{printf("\nEntre com o nome do automovel: ");
scanf("%s",&Carro[i].nome);
printf("Entre com a cor: ");
scanf("%s",&Carro[i].cor);
printf("Entre com o ano: ");
scanf("%d",&Carro[i].ano);
printf("Entre com o valor: ");
scanf("%f",&Carro[i].valor);
}
printf("\tnome \tcor \tano \tvalor \n");
for(i=0;i<2;i++)
{printf(" \t%s \t%s \t%d \t%.2f\n",Carro[i].nome,Carro[i].cor,Carro[i].ano,Carro[i].valor);}
getch();}
