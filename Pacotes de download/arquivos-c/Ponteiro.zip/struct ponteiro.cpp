#include <stdlib.h>
#include <stdio.h>
main(){
 int i, j, n;
 struct funcionario {int numero;
                     char nome[40];
                     long int cpf;
                     double salario;
                    };
 struct funcionario *tabfunc;

 scanf("%d", &n); // le n
 // aloca n elementos para v
 tabfunc = (struct funcionario *) malloc(n*sizeof(struct funcionario));
 // inicia os n elementos de tabfunc
 for (i = 0; i < n; i++){
   tabfunc[i].numero = 0;
   tabfunc[i].cpf = 999999;
   tabfunc[i].salario = -999999.99;
   for (j = 0; j < 40; j++) tabfunc[i].nome[j] = 'x';
 }
 
 // outra forma de iniciar os n elementos de tabfunc
 for (i = 0; i < n; i++){
   (tabfunc+i)->numero = 0;
   (tabfunc+i)->cpf = 9999999;
   (tabfunc+i)->salario = -999999.99;
   for (j = 0; j < 40; j++) (tabfunc+i)->nome[j] = 'x';
 }

 // outra forma de iniciar os n elementos de tabfunc
 for (i = 0; i < n; i++){
   (*(tabfunc+i)).numero = 0;
   (*(tabfunc+i)).cpf = 9999999;
   (*(tabfunc+i)).salario = -999999.99;
   for (j = 0; j < 40; j++) (*(tabfunc+i)).nome[j] = 'x';
 }

 // usa os n elementos de tabfunc
// ...
 // libera os n elementos de tabfunc
 free(tabfunc);
}
