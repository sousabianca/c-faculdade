# include<stdio.h>
# include<conio.h>

int main ()
{
float x[5]={10.0,3.1,5.0,1.2,1.6};
float *p;
p=x;
printf("%p", p);
printf ("\n%.2f e %p", *(p+0),(p+0));
printf ("\n%.2f e %p", *(p+1),(p+1));
printf ("\n%.2f e  %p", *(p+2),(p+2));
printf ("\n%.2f e  %p", *(p+5),(p+5));

getch();
return(0);
}
