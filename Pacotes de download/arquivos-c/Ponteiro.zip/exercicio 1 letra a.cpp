#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <math.h>

float Volume(float x){
	  float V;
	  V = pow(x,3);
	  return(V);	}

int main(){ 
 	  float a, V,;
 	  float (*pt)(float);
 	  pt=&Volume;
  	  puts("Digite a aresta do cubo:");
  	  scanf("%f", &a);
        V = (*pt)(a);   // chamada a fun��o 
  	  printf("\n O volume do cubo e' %.2f", V);
  	  system("PAUSE");}
