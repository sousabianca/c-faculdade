#include <conio.h>
#include <stdio.h>
#include <string.h>

struct automovel{
int ano,renavam;
char nome[15],marca[10],cor[10],combustivel[10];
}p[3];
 main()
{
//struct automovel;
int i;

for(i=0;i<2;i++)
{printf("\nEntre com o nome do automovel: ");
scanf("%s",&p[i].nome);
printf("Entre com a marca: ");
scanf("%s",&p[i].marca);
printf("Entre com a cor: ");
scanf("%s",&p[i].cor);
printf("Entre com o combustivel: ");
scanf("%s",&p[i].combustivel);
printf("Entre com o ano: ");
scanf("%d",&p[i].ano);
printf("Entre com o Renavam: ");
scanf("%d",&p[i].renavam);
}
printf("\tnome \tmarca \tcor \tcombustivel \tano \tRenavam\n");
for(i=0;i<2;i++)
{printf(" \t%s \t%s \t%s \t%s \t\t%d \t  %d\n",p[i].nome,p[i].marca,p[i].cor,p[i].combustivel, p[i].ano,p[i].renavam);}
getch();}
