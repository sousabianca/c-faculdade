#include <stdio.h>
#include <conio.h>
int main ()
{ int num,valor;//media;
int *p;
num=55;
p=&num; /* Pega o endereco de num */
valor=*p; /* Valor e igualado a num de uma maneira indireta */
printf ("\n\n num=%d\n\n",valor);
printf ("Endereco para onde o ponteiro aponta: p= %p\n\n",p);
printf ("Valor da variavel apontada:*p= %d\n\n",*p);
printf ("Endereco do ponteiro: &p= %x\n\n",&p);
printf ("Endereco de valor: &valor= %p\n\n",&valor);
//printf ("Endereco de valor: &media= %p\n\n",&media);
getch();
return(0);}
