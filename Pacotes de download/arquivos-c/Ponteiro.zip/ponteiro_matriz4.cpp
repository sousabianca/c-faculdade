# include<stdio.h>
# include<conio.h>

 main ()
{
short int matrx [50][50];
short int *p;
int count,i,j;
p=matrx[0];
for (count=0;count<2500;count++)
{
*p=0;
if (count==0)
{printf("\n\n Endere�o do elemento matriz[0][0] = %p   %f",&p[0],p);}
else
              if (count==2499)
              {printf("\n\n Endere�o do elemento matriz[49][49] = %p   %",&p[2499],p);}
              else
p++;
//printf("\n matriz[%d] = %p ",count,p);
}
printf("\n\n Endere�o do elemento matriz[0][0] = %p ",&p[0]);
{printf("\n Endere�o do elemento matriz[49][49] = %p ",&p[2499]);}//9996 bytes 50x50x4=10.000
getch();
return(0);
}
