#include <stdio.h>
#include <conio.h>
int syntax_error (int num)
{
static char *err[]={ "arquivo nao pode ser aberto\n","erro de leitura\n","erro de escrita\n","falha da midia\n"};
printf("%s",err[num]);
}
main()
{
      int x, resposta;
printf("entre com um numero entre 0 e 3\n");
scanf("%d",&x);
resposta=syntax_error(x);
getch();
return(0);
}
