#include <stdio.h>
#include <conio.h>
#include <string.h>
struct tipo_endereco
{        char rua [50];
        int numero;
        char bairro [20];
        char cidade [30];
        char sigla_estado [3];
        long int CEP;};

struct ficha_pessoal
{        char nome [50];
        long int telefone;
        struct tipo_endereco endereco;};

main (void)
{	struct ficha_pessoal ficha;
	strcpy (ficha.nome,"Jo�o Jos� a Silva");
	ficha.telefone=4921234;
	strcpy (ficha.endereco.rua,"Rua 31 de mar�o");
	ficha.endereco.numero=15;
	strcpy (ficha.endereco.bairro,"Centro");
	strcpy (ficha.endereco.cidade,"Resende");
	strcpy (ficha.endereco.sigla_estado,"RJ");
	ficha.endereco.CEP=27510230;
	printf("%s residente a %s numero %d",ficha.nome,ficha.endereco.rua,ficha.endereco.numero);
	printf("\nBairro: %s \nCidade: %s",ficha.endereco.bairro,ficha.endereco.cidade);
	printf(" \nEstado: %s \nCEP:%d",ficha.endereco.sigla_estado,ficha.endereco.CEP);
	getch();
	return 0;}
