/*Voc� pode criar um ponteiro para uma fn��o. O uso mais comum deste recurso 
� para passar uma fun��o como par�metro para outra fun��o. 
A declara��o de um ponteiro para uma fun��o segue a sintaxe:

TIPO (*FUN��O)();

Observe o uso disto no exemplo abaixo:*/

/* exemplificando o uso de ponteiro para uma fun��o */

#include <stdio.h>
#include <conio.h>

/* fun��o que identifica o maior entre dois inteiros */
int maior(int nr1,int nr2)
  {
    return((nr1 > nr2) ? nr1 : nr2);
  }

/* fun��o usa_maior(). Recebe dois inteiros e um
 * ponteiro para a fun��o maior()
 */
int usa_maior(int x,int y, int (*maior)())
  {
    return(maior(x,y));
  }

int main()
  {
    int a,b;

    printf("Entre com o primeiro n�mero: ");
    scanf("%d",&a);
    printf("Entre com o segundo n�mero: ");
    scanf("%d",&b);
    printf("O maior entre os dois � %d\n",usa_maior(a,b,&maior));
    /* observe logo acima que usa_maior() recebe como argumentos
     * dois n�meros inteiros e o endere�o da fun��o maior()
     * sendo, assim, coerente com sua declara��o
     */

    return(0);
  }
