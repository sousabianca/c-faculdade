#include <stdio.h>
#include <conio.h>
//#include <stream.h>

float fun(int a,int b){
float x;
  x=a*b;
  return(x);
}
 main(){
  float temp;
  float (*pt)(int,int);
  pt = &fun;
  temp = (*pt)(10,20); //eq�ivale a: temp = fun(10,20);
  printf("10X20=%.2f",temp);
  getch();
}
