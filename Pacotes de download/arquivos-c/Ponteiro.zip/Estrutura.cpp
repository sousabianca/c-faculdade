#include <stdio.h>
#include <conio.h>

struct lapis
{
int dureza;
char fabricante;
int numero;
};
main()
{
int i;
struct lapis p[3];
p[0].dureza=2;
p[0].fabricante='F';
p[0].numero=482;
p[1].dureza=1;
p[1].fabricante='B';
p[1].numero=652;

printf("Dureza Fabricante Numero\n");
for(i=0;i<2;i++)
printf("    %d\t   %c \t   %d\n",p[i].dureza,p[i].fabricante,p[i].numero);
getch();}
