/*Programa M�todo de Newton Raphson - C/C++ C/C++

Autor: Leonardo Pinheiro da Costa - ES

Vers�o: 2.0 */ 

#include <iostream.h>
#include <stdio.h>
#include <math.h>
#include <conio.h> 

//fun�ao

  double fx1(double x)

            {
                  double f1;
                  f1=pow(x,3)-9*x+3;
                  return(f1);
            } 

//derivada da fun�ao

      double dfx(double x)
      {
                  double dfx;
                  dfx=pow(3*x,2)-9;
                  return(dfx);
            }

void newton()
            {
                  double fx,fdx,xo,tol,x,a,b;
                  tol=0.00001;
                  printf("\n Digite o valor de A : ");
                  scanf("%f",&a);
                  printf("\n Digite o valor de B : ");
                  scanf("%f",&b);
                  xo=(a+b)/2;
                  fx=fx1(xo);
                  fdx=fx1(xo);
                        while (fabs(fx)>tol)
                              {
                                    x=xo-(fx/fdx);
                                    if (fabs(fx)<tol)
                              printf("\n Xo E RAIZ >>%f",x);
                                           else
                                                 xo=x;
                                                 fx=fx1(xo);
                         fdx=dfx(xo);
                               }
                                             printf("\n RAIZ : %f",x);
                                             getch();
            }
main()
            {
                  newton();
                  getchar();
            }
