#include <stdio.h>
#include <conio.h>
int main (){
short int vetor[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
short int *p;
p=vetor;
printf ("\n\n %p",(p+0));
printf ("\n\n %p",&p[0]);
printf ("\n\n %p",&vetor[0]);
printf ("\n\n %p",p);
printf ("\n\n %p",&p);
printf ("\n\n %p",vetor);
printf ("\n %d ",p[2]);
printf ("\n\n %d",*(p+2));
printf ("\n\n %d",vetor[2]);
printf ("\n\n %p",(p+2));
printf ("\n\n %p",&p[2]);
printf ("\n\n %p",&vetor[2]);
getch();}

