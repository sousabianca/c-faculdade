#include <stdio.h>
#include <conio.h>
#include <string.h>


typedef struct  
     {  
		     char nome[21];
  		     char cidade[21];
  		     char telefone[21]; 
 		     char *comentario;  	
     } Addr;
     Addr s; 
     char comm[100];
main()
{     gets(s.nome, 20);  
     gets(s.cidade, 20);  
     gets(s.telefone, 20); 
     gets(com., 100);  	
     s.coment�rio =       
     (char *)malloc(sizeof(char[strlen(comm)+1]));  
     strcpy(s.comentario, com.);  
}
/*
Esta t�cnica � �til quando apenas alguns registros realmente cont�m um
 coment�rio no campo de coment�rio. Se n�o houver nenhum coment�rio para 
 o registro, ent�o o campo consiste em apenas um ponteiro (4 bytes). 
 Depois, estes registros que t�m um coment�rio alocam exatamente o espa�o 
 necess�rio para manter a string de caracteres do coment�rio, com base na 
 extens�o do string digitada pelo usu�rio.      */
/*
struct tipo_endereco
{        char rua [50];
        int numero;
        char bairro [20];
        char cidade [30];
        char sigla_estado [3];
        long int CEP;};

struct ficha_pessoal
{        char nome [50];
        long int telefone;
        struct tipo_endereco endereco;};

main (void)
{	struct ficha_pessoal ficha;
	strcpy (ficha.nome,"Joao Jose da Silva");
	ficha.telefone=4921234;
	strcpy (ficha.endereco.rua,"Rua 31 de marco");
	printf("Entre com o numero \n");
	scanf("%d",&ficha.endereco.numero);
	strcpy (ficha.endereco.bairro,"Centro");
	strcpy (ficha.endereco.cidade,"Resende");
	strcpy (ficha.endereco.sigla_estado,"RJ");
	ficha.endereco.CEP=27510230;
	printf("\n%s residente a %s numero %d",ficha.nome,ficha.endereco.rua,ficha.endereco.numero);
	printf("\nBairro: %s \nCidade: %s",ficha.endereco.bairro,ficha.endereco.cidade);
	printf(" \nEstado: %s \nCEP:%d",ficha.endereco.sigla_estado,ficha.endereco.CEP);
	getch();
	return (0);}
	
*/
