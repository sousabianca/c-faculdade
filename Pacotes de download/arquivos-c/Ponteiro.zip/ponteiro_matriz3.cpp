# include<stdio.h>
# include<conio.h>

int main ()
{
float matriz [50][50];
float *p;
int count;
p=matriz[0];
for (count=0;count<2500;count++)
{
*p=0.1;
p++;
printf("\n matriz[%d] = %.4f ",count,p);
}
printf("\n\n Endere�o do elemento matriz[0][0] = %p ",(p+0));
printf("\n Endere�o do elemento &p[2499]= %p \t matriz[49][49] = %p",(p+2499),&matriz[49][49]);//9996 bytes 50x50x4=10.000
printf("\n o elemento matriz[49][49] = %f ",matriz[49][49]);
printf("\n o elemento matriz[49][49] = %f ",*(p+2499));
getch();
return(0);
}
