#include <stdio.h>
#include <conio.h>
#include <math.h>
 main ()
{

char opcao;
float a,b,x;
float *pt;
pt=&x;
puts("Selecione a opera��o matema'tica:\n");
puts("S- Soma; U-Subtracao; M-Multiplicacao; D-Divisao\n");
scanf("%c",&opcao);
{
printf("\n\t Entre com os dois numeros\n");
printf("\t 1o. numero:   ");scanf("%f",&a);
printf("\t 2o. numero:   ");scanf("%f",&b);
if (opcao=='s')
    { 
     x=a+b;
     printf("\n\t A soma e':");
     }    
else if(opcao=='u')
          {
           x=a-b;
           printf("\n\t A subtracao e':");
           }      
     else if(opcao=='m')
                   {
                    x=a*b;
                    printf("\n\t A multiplicacao e':");
                   }
          else if (opcao=='d')
                  {
                   x=a/b;
                   printf("\n\t A divisao e':");
                   }
               else
               printf("opcao invalida");
}                  
  //  pt=&x;
    printf("%.2f \a",*pt);
    printf("\n O endereco do resultado e:%p ",pt);
    getch();
}

