#define NCOLUNAS 2
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
// defini��o da fun��o
void imprimirVetor(int vetor[])
{
int i;
printf("\n O vetor digitado foi:\n");
for (i = 0; i < NCOLUNAS; i++) {
printf(" %d", vetor[i]); //imprime o vetor
}}

int main()
{
int i, j;
int numeros[NCOLUNAS]; //defini��o de um vetor de n�meros inteiros
for (i = 0; i < NCOLUNAS; i++) {
printf("Digite o elemento [%d] do vetor \n", i);
scanf("%d",&numeros[i]); //le valores para preencher o vetor
}
printf("\n\n\n");
imprimirVetor(numeros); //chamada da fun��o
printf("\n");
system("pause");
return 0;
}
