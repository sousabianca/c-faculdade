#include <stdio.h>
#include <conio.h>
#include <math.h>
 main ()
{
int count=10;
int *pt;
pt=&count;

    getch();
}

