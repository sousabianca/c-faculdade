# include<stdio.h>
# include<conio.h>

int main ()
{
float matriz[50][50];
float *p;
int count,i,j;
p=matriz[0];
for (count=0;count<2500;count++)
{
*p=10.0;
p++;
}
for (i=0;i<50;i++)
   for (j=0;j<50;j++)
{printf("\n matriz[%d][%d] = %f ",i,j,matriz[i][j]);}
getch();
return(0);
}
