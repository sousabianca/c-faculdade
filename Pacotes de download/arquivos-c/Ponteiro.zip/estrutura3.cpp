
#include <conio.h>
#include <stdio.h>
#include <string.h>
#define TAMANHO 4
struct data{
int dia, mes, ano;
};
struct aluno{
int matricula;
char nome[30];
struct data nascimento;
};
 main()
{
struct aluno turma[TAMANHO] = {
{9991, "Pedro", {10,5,1969}},
{9992, "Jose", {23,8,1977}},
{9993, "Paulo", {14,1,1970}},
{9994, "Joao", {2,10,1969}},
};
int i, achou;
int quem;
char escolha;
do{
//clrscr();
printf("\n Matricula: ");
scanf("%d", &quem);
achou = 0;
for(i=0; i<TAMANHO; i++)
if(quem==turma[i].matricula){
printf("Nome: %s\n", turma[i].nome);
printf("Nascimento: %02d/%02d/%04d\n",turma[i].nascimento.dia,turma[i].nascimento.mes,turma[i].nascimento.ano);
achou = 1;
break;
}
if(!achou)
printf("Nao Encontrado\n");
printf("\nContinuar? [S/N]");
escolha=getche();
}while(escolha=='s' || escolha=='S');
}
