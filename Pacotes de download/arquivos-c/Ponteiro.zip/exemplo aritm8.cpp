# include<stdio.h>
# include<conio.h>
int main ()
{
short int x=10, *p;
p=&x;
printf("p  =%p", &p);
printf("\np  =%p", p);
printf("\n*p  =%d", *p);
printf("\n x  =%d", x);
*p=*p+15;
printf("\n\np  =%p", p);
printf("\n*p  =%d", *p);
printf("\n x  =%d", x);
p=p+15;
printf("\n\np  =%p", p);
printf("\n*p  =%d", *p);
printf("\n x  =%d", x);
getch();
return(0);
}
