# include<stdio.h>
# include<conio.h>

int main ()
{
double x[3]={1.2,3.2,5.2};
double *p;
p=&x[0];
printf("p  =%p\n\n", p);
printf("\n*(p+0) =%f \t &x[0]= %p", *(p+0),(p+0));
printf("\n*(p+1) =%f \t &x[1]= %p", *(p+1),(p+1));
printf("\n*(p+2) =%f \t &x[2]= %p", *(p+2),(p+2));
p++;
printf("\n\n*(p-1) =%f \t &x[-1]= %p", *(p-2),(p-2));
printf("\n*(p+0) =%f \t &x[0]= %p", *(p+0),(p+0));
printf("\n*(p+1) =%f \t &x[1]= %p", *(p+1),(p+1));
getch();
return(0);
}
