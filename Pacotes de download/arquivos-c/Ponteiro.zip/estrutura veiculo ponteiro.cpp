#include <conio.h>
#include <stdio.h>
#include <string.h>

struct automovel{
int ano;
float valor;
char nome[15],cor[10];
}p[3];
 main()
{
int i;
struct automovel *pont;
pont = p;
for(i=0;i<2;i++)

{printf("\nEntre com o nome do automovel: ");
scanf("%s",&p[i].nome);
printf("Entre com a cor: ");
scanf("%s",&p[i].cor);
printf("Entre com o ano: ");
scanf("%d",&p[i].ano);
printf("Entre com o valor: ");
scanf("%f",&p[i].valor);
}
printf("\tnome \tcor \tano \tvalor \n");
for(i=0;i<2;i++)
{printf(" \t%s \t%s \t%d \t%.2f\n",p[i].nome,p[i].cor,p[i].ano,p[i].valor);}
{printf(" \t%c \t%c \t%d \t%.2f\n",*(pont+0).ano,*(pont+0).nome,*(pont+0).cor,*(pont+0).valor);}
getch();}
