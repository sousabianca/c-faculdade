#include <conio.h>
#include <stdio.h>
#include <string.h>
#define TAMANHO 4
struct data{
int dia;
char mes[20];
int ano;
};
 main()
{
 struct data p[3]={{15,"janeiro",1971},{21,"junho",1984},{29,"agosto",1992}};
 int i;
 
 printf("dia mes ano\n");
 for(i=0;i<3;i++)
 printf("    %d de %s de %d\n",p[i].dia,p[i].mes,p[i].ano);
 getch();
 }
