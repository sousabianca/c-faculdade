#include <stdio.h>
#include <conio.h>

struct lapis
{
int dureza;
char fabricante[20];
int numero;
};
main()
{
int i;
struct lapis p[3];
p[0].dureza=2;
printf("\nEntre com o fabricante:\t");
scanf("%s",&p[0].fabricante);
p[0].numero=482;
p[1].dureza=0;
printf("\nEntre com o fabricante:\t");
scanf("%s",&p[1].fabricante);
p[1].numero=33;
p[2].dureza=3;
printf("\nEntre com o fabricante:\t");
scanf("%s",&p[2].fabricante);
p[2].numero=107;
printf("Dureza Fabricante Numero\n");
for(i=0;i<3;i++)
printf("    %d\t   %s \t   %d\n",p[i].dureza,p[i].fabricante,p[i].numero);
getch();}
