# include<stdio.h>
# include<conio.h>

int main ()
{
int x;
int *p1, *p2;
p1=&x;
p2=p1;
printf("p2  =%p", p2);
p2++;
printf("\np2++=%p", p2);
getch();
return(0);
}
