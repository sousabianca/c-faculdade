# include<stdio.h>
# include<conio.h>

int main ()
{
int x=10;
int *p1, *p2;
p1=&x;
p2=p1;
printf(" p1= %p \n\n p2 =%p",p1, p2);
printf("\n\n *p1= %d \n\n *p2 =%d",*p1, *p2);
getch();
return(0);
}
