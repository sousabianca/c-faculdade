# include<stdio.h>
# include<conio.h>

int main ()
{
int x;
int *p1;
p1=&x;
printf("p1  = %p", p1);
p1++;
printf("\np1++= %p", p1);
getch();
return(0);
}
