# include<stdio.h>
# include<conio.h>

int main ()
{
int x[3]={1,3,5};
int *p;
p=&x[0];
printf("p  =%p", p);
printf("\n*(p+0) =%d \t &x[0]= %p", *(p+0),(p+0));
printf("\n*(p+1) =%d \t &x[1]= %p", *(p+1),(p+1));
printf("\n*(p+2) =%d \t &x[2]= %p", *(p+2),(p+2));
p++;
printf("\n\n*(p+0) =%d \t &x[0]= %p", *(p+0),(p+0));
printf("\n*(p+1) =%d \t &x[1]= %p", *(p+1),(p+1));
printf("\n*(p-1) =%d \t &x[-1]= %p", *(p-1),(p-1));
getch();
return(0);
}
