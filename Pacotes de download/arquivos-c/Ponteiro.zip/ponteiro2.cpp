#include <stdio.h>
#include <conio.h>
main(void)
{
char frase[]="teste";
char *p;
int i;

printf("%s\n",frase);
p=frase; /* Mesmo que ponteiro=&nome[0]; */
printf("Usando o indice\n");
for(i=0; p[i]!='\0'; i++)
printf("%c\n",p[i]);
printf("Incrementando o ponteiro\n");
while(*p!='\0'){
printf("%c\n", *p);
p++;
}
getch();}
