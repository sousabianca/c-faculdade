/* percorrendo uma matriz de strings com um ponteiro */

#include <stdio.h>
#include <conio.h>

int main()
  {
    char *dia[] = {"Domingo","Segunda","Ter�a","Quarta","Quinta","Sexta","S�bado",0};
    char **ptr_dia;

    /* *dia � um ponteiro para uma string e
     * **ptr_dia � um ponteiro para um ponteiro para uma string
     */

    ptr_dia = dia; /* apontando ptr_dia para o in�cio da matriz dia */

    while(*ptr_dia)
      {
        printf("%s\n",*ptr_dia);
        ptr_dia++;
      }
    getch();
    return(0);

  }

  /* Quando voc� declara uma matriz de strings o compilador
   * n�o acrescenta um caractere NULL para indicar o final
   * da matriz como o faz com uma matriz de caracteres (strings).
   * Por isso voc� mesmo tem que inserir o caractere NULL para
   * indicar o final da matriz.
   *
   * Foi isso que foi feito ao inserir 0 no final da matriz dia
   */
