# include<stdio.h>
# include<conio.h>
int main ()
{
int x, *p1, *p2;
int vetor_A[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
int vetor_B[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
p1=vetor_A;
p2=vetor_B;
if (&p1[2]>&p2[2])
printf("\n\nendereco de p1 %p",&p1[2]);
else
printf("\n\n endereco de p2 %p",&p2[3]);
getch();
return(0);
}
