#include <stdio.h>
#include <conio.h>
int main ()
{
int num,*p;
num=55;
p=&num; /* Pega o endereco de num */
printf ("\nValor inicial: %d\n",*p);
*p=100; /* Muda o valor de num de uma maneira indireta*/
printf ("\nValor modificado de modo indireto: %d\n",num);
getch();
return(0);
}
