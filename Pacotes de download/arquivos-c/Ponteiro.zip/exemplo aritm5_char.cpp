# include<stdio.h>
# include<conio.h>

int main ()
{
char x[3]={'A','B','C'};
char *p;
p=&x[0];
printf("p  =%p\n\n", p);
printf("\n*(p+0) =%c \t &x[0]= %p", *(p+0),(p+0));
printf("\n*(p+1) =%c \t &x[1]= %p", *(p+1),(p+1));
printf("\n*(p+2) =%c \t &x[2]= %p", *(p+2),(p+2));
p++;
printf("\n\n*(p-1) =%c \t &x[-1]= %p", *(p-1),(p-1));
printf("\n*(p+0) =%c \t &x[0]= %p", *(p+0),(p+0));
printf("\n*(p+1) =%c \t &x[1]= %p", *(p+1),(p+1));
getch();
return(0);}
