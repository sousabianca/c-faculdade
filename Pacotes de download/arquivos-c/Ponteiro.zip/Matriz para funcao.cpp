#define NLINHAS 2
#define NCOLUNAS 2
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
// defini��o da fun��o
void imprimirMatriz(int matriz[][NCOLUNAS]) 
// veja que n�o � necess�rio definir a primeira dimens�o
{
int i, j;
printf("\n A matriz digitada foi:\n");
for (i = 0; i < NLINHAS; i++) {
for (j = 0; j < NCOLUNAS; j++){
printf(" %d", matriz[i][j]); //imprime a matriz
}
printf("\n"); // pula uma linha s� para separar as linhas da matriz
}
}
int main()
{
int i, j;
int numeros[NLINHAS][NCOLUNAS]; //defini��o de uma matriz de n�meros inteiros
for (i = 0; i < NLINHAS; i++) {
for (j = 0; j < NCOLUNAS; j++){
printf("Digite o elemento [%d,%d] da matriz \n", i, j);
scanf("%d",&numeros[i][j]); //le valores para preencher a matriz
}}
printf("\n\n\n");
imprimirMatriz((numeros+0)); //chamada da fun��o
printf("\n");
system("pause");
return 0;
}
