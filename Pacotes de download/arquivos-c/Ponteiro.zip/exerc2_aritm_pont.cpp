#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

main()
{
float Resp, b, a;
float *pta,*ptb;
pta=&a;
ptb=&b;
      printf("Entre com os valores de a e b\n");
      scanf("%f %f",&a,&b);
	  if (pta>ptb)
	  printf("\nO endereco de a e' maior que b: %p > %p",pta,ptb);
	  else
	  printf("\nO endereco de b e' maior que a: %p > %p",ptb,pta);
	  getch();
   }
