# include<stdio.h>
# include<conio.h>
int main ()
{
int x, *p2, *p1;

int vetor_A[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
int vetor_B[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };


p1=&vetor_A[0];
p2=&vetor_B[0];
               if (p1>p2)
                   {printf("\n\nO endereco de p1 %p e maior que p2 %p",p1,p2);
                    printf("\n\nO endereco de p1 +9 =%d",vetor_A[9]);}
               else
                   {printf("\n\n O conteudo de p2 %p e' maior que o conteudo de p1 %p",p2,p1);}

printf("\n\n *p2= %d  *p1= %d",*(p2+0),*(p1+0));
getch();
return(0);
}
