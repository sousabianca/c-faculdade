# include<stdio.h>
# include<conio.h>
# include<math.h>
float Volume(float *pt)
{	  float V;
	  *pt=10;
	  V = pow(*pt,3);

	  return(V);	}
int main()
{  	  float a, V,;
  	  puts("Digite a aresta do cubo:");
  	  scanf("%f", &a);
        V = Volume(&a);   // chamada a fun��o 
  	  printf("\n O volume do cubo e' %.2f", V);
  	  printf("\n O valor da aresta modificada pela funcao e' %.2f", a);
  	  getch();}
