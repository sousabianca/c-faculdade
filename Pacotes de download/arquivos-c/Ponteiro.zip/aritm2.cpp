# include<stdio.h>
# include<conio.h>

int main ()
{
int y,x=10;
int *p1, *p2;
p1=&x;
p2=&y;
*p2=*p1;
printf("*p1= %d", *p1);
printf("\n*p2= %d", *p2);
getch();
return(0);
}
