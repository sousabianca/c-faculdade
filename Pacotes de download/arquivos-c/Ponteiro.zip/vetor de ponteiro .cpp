#include <stdio.h>
#include <conio.h>
int main ()
{
 int vetor[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
 int *p;
p=vetor;
//printf ("\n O conteudo do terceiro elemento do vetor e:p[2]= %d ",p[2]);
printf ("\n\n O conteudo do terceiro elemento do vetor e:*(p+2)= %d",*(p+2));
//printf ("\n\n O conteudo do terceiro elemento do vetor e:vetor[2]= %d",vetor[2]);
printf ("\n\n O endereco do terceiro elemento do vetor e:p= %p",p);
//printf ("\n\n O endereco do terceiro elemento do vetor e:&p[2]= %p",&p[2]);
//printf ("\n\n O endereco do terceiro elemento do vetor e:&vetor[2]= %p",&vetor[2]);
getch();
return(0);
}
