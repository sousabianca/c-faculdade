# include<stdio.h>
# include<conio.h>
int main ()
{
short int x=10, *p;
p=&x;
printf("p  =%p  &p =%p", p,&p);
printf("\np  =%d", *p);
printf("\nx  =%d", x);
(*p)++;
printf("\n\np  =%p", p);
printf("\np  =%d", *p);
printf("\nx  =%d", x);
getch();
return(0);
}
