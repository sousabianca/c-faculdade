# include<stdio.h>
# include<conio.h>

int main ()
{
int y=15,x=10;
int *px, *py, *p3;
px = &x;
py = &y;
printf("*p1 = %d", *px);
printf("\n*p2 = %d", *py);
printf("\n\n p1 = %p \n\n p2 =%p",px, py);
printf("\n\n p1 = %p \n\n p2 =%p",&x, &y);
printf("\n\n p1 = %p \n\n p2 =%p",&px, &py);

*px = *py;
printf("\n\n*p1 = %d", *px);
printf("\n*p2 = %d", *py);
printf("\n\n p1 = %p \n\n p2 =%p",px, py);

p3 = py ;
printf("\n\n p2 =%p",py);
printf("\n\n p3 =%p",p3);
printf("\n\n*p2 = %d", *py);
printf("\n*p3 = %d", *p3);
getch();
return(0);
}
