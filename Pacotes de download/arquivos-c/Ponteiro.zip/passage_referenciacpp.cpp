#include <stdio.h>
#include <conio.h>

int soma(int *a)
{
int x=5;
x = 2 * x + *a;
*a = 0;
return(x);
}

main()
{
int a,r,x;
printf("Digite um valor: ");
scanf("%d",&a);
x = 2 * a + 3;
r = soma(&a);
printf("%d, %d e %d",a,x,r);
getch();
}
