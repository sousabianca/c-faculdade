#include <stdio.h>
#include <conio.h>
int main ()
{
short int vetor1[10] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
short int vetor2[10] = { 1, 2, 3, 4, 5 };
short int *p;
p=vetor1;
printf ("\n\n O conteudo do primeiro elemento do vetor e:\n\n *p = %d  ou  *(p+0) = %d",*p,*(p+0));
printf ("\n\n O conteudo do primeiro e do ultimo elemento do vetor e:\n\n *(p+0)= %d  \n *(p+9)= %d",*(p+0),*(p+9));
printf ("\n\n O endereco do primeiro e do ultimo elemento do vetor e:\n\n &p[0]= %p  \n &p[9]= %p",&p[0],&p[9]);
printf ("\n\n O endereco do primeiro e do ultimo elemento do vetor e:\n\n (p+0)= %p  \n (p+9)= %p",(p+0),(p+9));
getch();
return(0);
}
