# include<stdio.h>
# include<conio.h>
int main ()
{
short int x=10, *p1, *p2;
p1=&x;
p2=p1+15;
printf("p1  =%p", p1);
printf("\np1  =%d", *p1);
printf("\np2+15=%p", p2);
*p2=*p1;
printf("\np2+15=%d", *p2);
getch();
return(0);
}
