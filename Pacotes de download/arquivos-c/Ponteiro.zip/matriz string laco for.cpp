/* percorrendo uma matriz de strings com um la�o for */

#include <stdio.h>
#include <conio.h>
int main()
  {
    char *dias[7] = {"Domingo","Segunda","Ter�a","Quarta","Quinta","Sexta","Sabado"};
    int contador;

    for(contador = 0;contador < 7;contador++)
      printf("%do dia da semana = %s\n",contador+1,dias[contador]);
getch();
    return(0);
  }
