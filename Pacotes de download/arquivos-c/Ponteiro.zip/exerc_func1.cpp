#include <stdio.h>
#include <conio.h>
#include <math.h>

float Media(float *a, float *b)
{	  float x;
	  x = (*a + *b)/2;
   	//  *a=5;
    // *b=6;
	  return(x);}

int main()
{  
  	  float num_1, num_2, Resp;
  	  puts("Digite dois numeros:");
  	  scanf(" %f %f", &num_1, &num_2);
        Resp = Media(&num_1, &num_2);   // chamada a fun��o 
  	  printf("\nA media destes numeros e' %.2f", Resp);
  	  printf("\n num1=%f \t num2= %f", num_1,num_2);
  	  getch();
}
