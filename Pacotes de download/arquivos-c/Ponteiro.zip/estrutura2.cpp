#include <conio.h>
#include <stdio.h>
#include <string.h>

struct data{
int dia;
char mes[20];
int ano;
}p[3],x[5];
 main()
{
//struct data p[3];
int i;
for(i=0;i<3;i++)
{printf("Entre com o dia: ");
scanf("%d",&p[i].dia);
printf("Entre com o mes: ");
scanf("%s",&p[i].mes);
printf("Entre com o ano: ");
scanf("%d",&p[i].ano);
}
printf("dia mes ano\n");
for(i=0;i<3;i++)
{printf(" %d de %s de %d\n",p[i].dia,p[i].mes,p[i].ano);}
getch();}
