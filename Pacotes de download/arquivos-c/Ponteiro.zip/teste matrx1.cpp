# include<stdio.h>
# include<conio.h>
int main ()
{
int matrx[10],*p;
int count;
p=matrx;

for(count=0;count<10;count++)
{
*p=1;
//p++;
printf("\n %d",*(p+count));
}
getch();
return(0);
}
