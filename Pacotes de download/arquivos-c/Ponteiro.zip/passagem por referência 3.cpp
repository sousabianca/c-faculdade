#include <stdio.h>
#include <stdlib.h>
// observe que o primeiro par�metro � passado por valor e o segundo por refer�ncia
void incrementar(int n1, int *n2)
{
n1 = n1 + 1;
*n2 = *n2 + 1;
}
int main () // o programa principal
{
int valor1, valor2;
puts("Digite o primeiro valor: ");
scanf("%d", &valor1); // observe que o scanf usa o endere�o da vari�vel valor1
puts("Digite o segundo valor: ");
scanf("%d", &valor2);
printf("\nOs valores ANTES do incremento: Valor1 = %d e Valor2 = %d", valor1, valor2);
/* como primeiro argumento da fun��o passamos o valor da vari�vel valor1 (que ser�
copiado para n1). J� como segundo par�metro, passamos o endere�o da vari�vel
valor2 */
incrementar(valor1, &valor2);
printf("\nOs valores DEPOIS do incremento: Valor1 = %d e Valor2 = %d \n", valor1, valor2);
system("pause");
return(0);
          }
