#include <stdio.h>
#include <conio.h>

int main()
{
float nota[5][3] = {{8.4,7.4,5.7}, 
                    {6.9,2.7,4.9}, 
                   	{4.5,6.4,8.6},
                    {4.6,8.9,6.3},
	                {7.2,3.6,7.7}};
int i, j; 
printf("\n A Matriz_A e' =:\n");

//***********impress�o da matriz********************
 /*for(i=0; i < 5; i++) 
  for(j=0; j < 3; j++) 
  printf("\n\t  nota[%d][%d]  ->  [%.2f]",i,j, nota[i][j]); */
    
//***********impress�o da matriz********************  
printf("\n\n\n");
 /*for(i=0; i < 5; i++) 
 {
  for(j=0; j < 3; j++) 
   {
    printf("\t %.2f",nota[i][j]);
   }
   printf("\n");
}   */
  printf("\tnota[0][0]= %p",(nota+2));
  printf("\n\tnota[0][0]= %p",&nota[2][0]);

  printf("\n\tnota[0][0]= %p",(nota+11));
  printf("\n\tnota[3][2]= %p",&nota[3][2]);
    
  printf("\n\n\tnota[0][0]= %p",(nota+2+1));
  printf("\n\tnota[0][0]= %p",&nota[2][1]);
         getch();
       }  
 
 
