# include<stdio.h>
# include<conio.h>
int main ()
{
short int x[16]={0,1,2,3,4,5,6,7,8,9,10,11,24,13,14,15};
short int *p,i=1;
p=&x[0];

printf("p  =%p", p);
printf("\np  =%d", *p);
printf("\n *(p+15)=%d", *(p+i+14));
//somando 3 no conte�do de x[15]
printf("\n\n dividindo o conte�do de x[15] por 3:");

printf("\n *(p+12)=%d", *(p+12)/3);
getch();
return(0);
}
