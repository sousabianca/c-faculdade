#include <stdio.h>
#include <conio.h>
#include <string.h>

char PrintString (char *str, int (*func)(const char *));
main ()
{
char String [20]="Curso de C.";
int (*p)(const char *); 
/* Declaracao do ponteiro para fun��o Funcao apontada e' inteira e recebe
como parametro uma string constante */
p=puts; /* O ponteiro p passa a apontar para a fun��o puts
que tem o seguinte prototipo: int puts(const char *) */
PrintString (String, p); /* O ponteiro � passado como parametro para PrintString */
getch();
return 0;
}
