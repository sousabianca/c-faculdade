#include <stdio.h>
#include <conio.h>
main(){
int count=10;
int *pt;
pt=&count;
*pt=7;
printf("count= %d\n\n",count);
printf("*pt= %d\n\n",*pt);
printf("pt= %p\n\n",pt);//endere�o em hexadecimal
printf("&count= %p\n\n",&count);//endere�o em decimal
  getch();
}
