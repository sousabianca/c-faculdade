
#include <licrypto.h>
#include <conio.h>

main(){
char str[80];
strcpy("alo",str);
puts(str);
}
