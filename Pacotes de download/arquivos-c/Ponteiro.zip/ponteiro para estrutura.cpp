#include<stdio.h>
#include<conio.h>
struct data{
int dia, mes, ano;
};
int exibedata(struct data *pd)//pd=&dt1
{
char *meses[12]={"Janeiro", "Fevereiro", "Marco", "Abril", "Maio",
"Junho", "Julho", "Agosto", "Setembro", "Outubro",
"Novembro", "Dezembro"};
printf("%02d de %s de %04d", pd->dia, meses[pd->mes-1], pd->ano);
};
 main()
{
struct data dt1;
printf("Informe uma data:");
scanf("%d%d%d",&dt1.dia,&dt1.mes,&dt1.ano);
exibedata(&dt1);
getch();
}
