#include <stdio.h>
#include <conio.h>
int main (){
int i=0;
float x,y=10.0;
scanf("%f",&x);
do {
    y=y+3;
    printf("\n  i= %d  y= %.2f",i,y);
    i++;  }
while (i<=5);
printf("\n x= %.2f",x);
getch();}

