#include <stdio.h>

int mostra(int num);
int num[]; /* ou declarar int *num; */
{
int i;
for(i=0;i<10;i++)printf("%d",num[i]);
}
main()
{int t[10],i;
for(i=0;i<10;i++)
t[i]=i;
mostra(t);
}

