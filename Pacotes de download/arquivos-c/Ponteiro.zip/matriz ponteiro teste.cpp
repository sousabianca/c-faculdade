 #include <stdio.h>
#include <conio.h>
int main ()
{
float matrx[5][5];
float *p;
int count,j=2;
p=matrx[0];
for (count=0;count<25;count++)
{
*p=20.0;
p++;
}
for (count=0;count<25;count++)
//{printf("\np(%d)=%f",count,p[count]);}
//for (count=0;count<5;count++)
//{for (j=0;j<5;j++)
//printf("\nmatrx[%d][%d]=%.2f",count,j,matrx[count][j]);
//printf("\nmatrx[%d][%d]=%.2f",count,j,*(p+(count*5)+ j));}
{printf("\nmatrx[1][2]=%.2f",*(p+count));}
printf("\nmatrx[1][2]=%.2f",matrx[4][2]);
getch();
return(0);
}
